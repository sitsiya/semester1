-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2017 at 03:23 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashion_villa`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--

CREATE TABLE `bank_account` (
  `bank_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `bank_name` varchar(30) DEFAULT NULL,
  `bank_account` varchar(30) DEFAULT NULL,
  `bank_account_no` int(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_account`
--

INSERT INTO `bank_account` (`bank_id`, `customer_id`, `bank_name`, `bank_account`, `bank_account_no`) VALUES
(1, 2, 'Scotia Bank', 'Saving', 2147483647),
(2, 3, 'ICICI Bank', 'Credit', 2147483647),
(3, 5, 'Axis Bank', 'Saving', 2147483647),
(4, 6, 'BMC Bank', 'Credit', 2147483647),
(5, 1, 'RBC Bank', 'Saving', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `catagory`
--

CREATE TABLE `catagory` (
  `catagory_id` int(20) NOT NULL,
  `catagory_name` varchar(25) NOT NULL,
  `catagor_discription` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `catagory`
--

INSERT INTO `catagory` (`catagory_id`, `catagory_name`, `catagor_discription`) VALUES
(1, 'jean', ''),
(2, 'gloves', ''),
(3, 'top', ''),
(4, 'shirt', ''),
(5, 'shrug', ''),
(6, 'jacket', ''),
(7, 'coat', ''),
(8, 'muffler', ''),
(9, 'socks', ''),
(10, 'cap', '');

-- --------------------------------------------------------

--
-- Stand-in structure for view `number_of_products_suppliedby_supplier`
-- (See below for the actual view)
--
CREATE TABLE `number_of_products_suppliedby_supplier` (
`name` varchar(30)
,`contact_no` int(10)
,`supplier_id` int(11)
,`COUNT(supplier_product.product_id)` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `order_status` varchar(30) DEFAULT NULL,
  `payment_type` varchar(30) DEFAULT NULL,
  `payment_status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `bank_id`, `customer_id`, `date`, `supplier_id`, `order_status`, `payment_type`, `payment_status`) VALUES
(1, 2, 1, '2016-11-15', 2, 'not shipped', 'Credit Card', 'pending'),
(2, 1, 1, '2016-12-15', 2, 'not shipped', 'Debit Card', 'pending'),
(3, 5, 1, '2016-12-14', 3, 'shipped', 'Credit Card', 'pending'),
(4, 3, 2, '2016-12-13', 1, 'canceled', 'Credit Card', 'pending'),
(5, 4, 1, '2016-12-12', 2, 'shipped', 'Credit Card', 'done'),
(6, 2, 4, '2016-11-29', 3, 'shipped', 'Debit Card', 'done'),
(7, 5, 3, '2016-11-20', 5, 'not shipped', 'Debit Card', 'pending'),
(8, 3, 5, '2016-11-15', 2, 'shipped', 'Credit Card', 'done'),
(9, 2, 1, '2016-11-15', 2, 'not shipped', 'Credit Card', 'pending'),
(10, 4, 1, '2016-11-15', 2, 'not shipped', 'Debit Card', 'pending');

-- --------------------------------------------------------

--
-- Stand-in structure for view `ordersoldbygender`
-- (See below for the actual view)
--
CREATE TABLE `ordersoldbygender` (
`gender` enum('M','F')
,`Number_of_Products_Sold` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `order_detail_id` int(20) NOT NULL,
  `product_id` int(20) NOT NULL,
  `order_id` int(20) NOT NULL,
  `quantity` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`order_detail_id`, `product_id`, `order_id`, `quantity`) VALUES
(1, 1, 2, 6),
(2, 1, 2, 6),
(3, 1, 3, 4),
(4, 2, 1, 1),
(5, 2, 3, 2),
(6, 3, 4, 1),
(7, 4, 7, 3),
(8, 5, 6, 5),
(9, 6, 10, 8),
(10, 7, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `p_name` varchar(50) DEFAULT NULL,
  `p_desc` varchar(200) DEFAULT NULL,
  `catagory_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `price` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `p_name`, `p_desc`, `catagory_id`, `supplier_id`, `discount`, `price`) VALUES
(1, 'shrug', NULL, 5, 1, 0, 50),
(2, 'jeans', NULL, 5, 3, 1, 30),
(3, 'gloves', NULL, 2, 1, 0, 40),
(4, 'top', NULL, 3, 2, 3, 20),
(5, 'shirt', NULL, 4, 1, 0, 10),
(6, 'shrug', NULL, 5, 4, 5, 80),
(7, 'gloves', NULL, 2, 6, 2, 40),
(8, 'gloves', NULL, 2, 8, 1, 10),
(9, 'top', NULL, 3, 7, 1.9, 30),
(10, 'top', NULL, 3, 10, 0.8, 20);

-- --------------------------------------------------------

--
-- Stand-in structure for view `productsellbymonth`
-- (See below for the actual view)
--
CREATE TABLE `productsellbymonth` (
`product_id` int(11)
,`p_name` varchar(50)
,`extract(month from orders.date)` int(2)
);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(30) DEFAULT NULL,
  `gender` enum('M','F') NOT NULL,
  `contact_no` int(10) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `pass_word` varchar(30) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`customer_id`, `customer_name`, `gender`, `contact_no`, `address`, `city`, `postal_code`, `state`, `country`, `pass_word`, `bank_id`) VALUES
(1, 'Krishna Kothari', 'M', 2147483647, '4505 radhanagar', 'Memnagar', 'M4N5K6', 'Gujarat', 'India', '4567372gr', 1),
(2, 'Nishit Patel', 'M', 2147483647, '50 Dempster', 'Scarborough', 'V5N6K5', 'Toronto', 'Canada', 'nwfi453fi3', 2),
(3, 'Nidhi Sharma', 'F', 2147483647, '567 Golf Club ', 'Scarborough', 'D7F7G8', 'Toronto', 'Canada', 'fbv788evwe78', 3),
(4, 'Shreyas Patel', 'M', 2147483647, '45 Allanford ', 'Scarborough', 'A6D6E6', 'Toronto', 'Canada', '4gr987yfihe', 4),
(5, 'Krutvi Shah', 'F', 2147483647, 'Cass Avenue', 'Scarborough', 'C8V7B6', 'Toronto', 'Canada', 'n23hfhh393h', 5),
(6, 'Harpreet Kaur', 'F', 2147483647, 'Victoria Park', 'Scarborough', 'D9F8G7', 'Toronto', 'Canada', '4vieh39ur', 2),
(7, 'Meena Shah', 'F', 2147483647, 'Keneddy Road', 'Scarborough', 'S9D9G8', 'Toronto', 'Canada', '459ftf393389', 3),
(8, 'Karina Kapoor', 'F', 2147483647, '68 Warden Avenue', 'Scarborough', 'S6D7G8', 'Toronto', 'Canada', 'fjoej359h5h', 5),
(9, 'Ridhdhi Bhatt', 'F', 2147483647, '505 Fioel sparrow', 'Brampton', 'X9C7V6', 'Toronto', 'Canada', '89243678fhui', 1),
(10, 'Snehal Rathod', 'M', 2147483647, '1035 Markham Road', 'Scarborough', 'M4C9S7', 'Toronto', 'Canada', 'hfgihh488u4', 4);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `contact_no` int(10) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `name`, `contact_no`, `address`, `city`, `postal_code`, `country`) VALUES
(1, 'Chaitali Patel', 2147483647, 'North York', 'Scarborough', 'M2T5R9', 'Canada'),
(2, 'Hardeep Kaur', 2147483647, '2075 warden avenue', 'Scarborough', 'M1T3R1', 'Canada'),
(3, 'Manpreet Kaur', 2147483647, '50 Dempster Street', 'Scarborough', 'M1T2T5', 'Canada'),
(4, 'Damini Vakani', 2147483647, '567 Golf Club Road', 'Scarborough', 'M3R2T5', 'Canada'),
(5, 'Paresh Patel', 2147483647, '520 MiddleField Road', 'Scarborough', 'M2S1T8', 'Canada'),
(6, 'Rajvir Sinha', 2147483647, '45 Allanford Road', 'Scarborough', 'M1T2T5', 'Canada'),
(7, 'Kajal Prajapati', 2147483647, 'Cass Avenue', 'Scarborough', 'M1T3R2', 'Canada'),
(8, 'Mccreaw Gill', 2147483647, 'Victoria Park Avenue', 'Scarborough', 'M1T5R1', 'Canada'),
(9, 'Sonali Sharma', 2147483647, 'Keneddy Road', 'Scarborough', 'M1T2T6', 'Canada'),
(10, 'Shalini Rathod', 2147483647, '68 Warden Avenue', 'Scarborough', 'M1T3R1', 'Canada');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_product`
--

CREATE TABLE `supplier_product` (
  `sp_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_product`
--

INSERT INTO `supplier_product` (`sp_id`, `supplier_id`, `product_id`) VALUES
(1, 1, 10),
(2, 2, 8),
(3, 3, 3),
(4, 4, 7),
(5, 5, 2),
(6, 6, 1),
(7, 7, 7),
(8, 8, 9),
(9, 9, 6),
(10, 10, 5);

-- --------------------------------------------------------

--
-- Stand-in structure for view `top5customers`
-- (See below for the actual view)
--
CREATE TABLE `top5customers` (
`customer_name` varchar(30)
,`gender` enum('M','F')
,`contact_no` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `top_2_product`
-- (See below for the actual view)
--
CREATE TABLE `top_2_product` (
`product_id` int(11)
,`p_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `number_of_products_suppliedby_supplier`
--
DROP TABLE IF EXISTS `number_of_products_suppliedby_supplier`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `number_of_products_suppliedby_supplier`  AS  select `supplier`.`name` AS `name`,`supplier`.`contact_no` AS `contact_no`,`supplier`.`supplier_id` AS `supplier_id`,count(`supplier_product`.`product_id`) AS `COUNT(supplier_product.product_id)` from (`supplier` join `supplier_product` on((`supplier`.`supplier_id` = `supplier_product`.`supplier_id`))) group by `supplier_product`.`supplier_id` order by count(`supplier_product`.`product_id`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `ordersoldbygender`
--
DROP TABLE IF EXISTS `ordersoldbygender`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ordersoldbygender`  AS  select `registration`.`gender` AS `gender`,count(0) AS `Number_of_Products_Sold` from (`registration` join `orders` on((`registration`.`customer_id` = `orders`.`customer_id`))) where (`orders`.`order_status` = 'shipped') group by `registration`.`gender` ;

-- --------------------------------------------------------

--
-- Structure for view `productsellbymonth`
--
DROP TABLE IF EXISTS `productsellbymonth`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `productsellbymonth`  AS  select `product`.`product_id` AS `product_id`,`product`.`p_name` AS `p_name`,extract(month from `orders`.`date`) AS `extract(month from orders.date)` from ((`product` join `order_detail` on((`product`.`product_id` = `order_detail`.`product_id`))) join `orders` on((`order_detail`.`order_id` = `orders`.`order_id`))) group by `product`.`product_id` order by count(`order_detail`.`product_id`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `top5customers`
--
DROP TABLE IF EXISTS `top5customers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `top5customers`  AS  select `registration`.`customer_name` AS `customer_name`,`registration`.`gender` AS `gender`,`registration`.`contact_no` AS `contact_no` from (`registration` join `orders` on((`registration`.`customer_id` = `orders`.`customer_id`))) group by `registration`.`customer_id` order by count(`orders`.`customer_id`) desc limit 5 ;

-- --------------------------------------------------------

--
-- Structure for view `top_2_product`
--
DROP TABLE IF EXISTS `top_2_product`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `top_2_product`  AS  select `product`.`product_id` AS `product_id`,`product`.`p_name` AS `p_name` from (`product` join `order_detail` on((`product`.`product_id` = `order_detail`.`product_id`))) group by `product`.`product_id` order by count(`product`.`product_id`) desc limit 2 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_account`
--
ALTER TABLE `bank_account`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `catagory`
--
ALTER TABLE `catagory`
  ADD PRIMARY KEY (`catagory_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `orders_customer_id_fk` (`customer_id`),
  ADD KEY `orders_supplier_id_fk` (`supplier_id`),
  ADD KEY `orders_bank_id_fk` (`bank_id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`order_detail_id`),
  ADD KEY `order_detail_product_id_fk` (`product_id`),
  ADD KEY `order_detail_order_id_fk` (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `product_catagory_id_fk` (`catagory_id`),
  ADD KEY `product_supplier_id_fk` (`supplier_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`customer_id`),
  ADD KEY `registration_bank_id_fk` (`bank_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `supplier_product`
--
ALTER TABLE `supplier_product`
  ADD PRIMARY KEY (`sp_id`),
  ADD KEY `supplier_product_product_id_fk` (`product_id`),
  ADD KEY `supplier_product_supplier_id_fk` (`supplier_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_bank_id_fk` FOREIGN KEY (`bank_id`) REFERENCES `bank_account` (`bank_id`),
  ADD CONSTRAINT `orders_customer_id_fk` FOREIGN KEY (`customer_id`) REFERENCES `registration` (`customer_id`),
  ADD CONSTRAINT `orders_supplier_id_fk` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`);

--
-- Constraints for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `order_detail_order_id_fk` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_detail_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_catagory_id_fk` FOREIGN KEY (`catagory_id`) REFERENCES `catagory` (`catagory_id`),
  ADD CONSTRAINT `product_supplier_id_fk` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`);

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `registration_bank_id_fk` FOREIGN KEY (`bank_id`) REFERENCES `bank_account` (`bank_id`);

--
-- Constraints for table `supplier_product`
--
ALTER TABLE `supplier_product`
  ADD CONSTRAINT `supplier_product_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `supplier_product_supplier_id_fk` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
