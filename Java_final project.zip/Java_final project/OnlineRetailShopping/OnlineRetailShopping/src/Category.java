

public class Category {

private String Category_id;
private String Category_Name;
 
Category(String Category_id,String Category_Name){
	 this.Category_id = Category_id;
	 this.Category_Name = Category_Name;
	 
 }
 public String getCategoryid()
	{
		return Category_id;
	}
	public void setCategoryid(String Category_id)
	{
		this.Category_id = Category_id;
	}
	
	@Override
	public String toString() {
		return "Category [Category_id=" + Category_id + ", Category_Name="
				+ Category_Name + "]";
	}
	public String getCategoryName()
	{
		return Category_Name;
	}
	public void setCategoryName(String Category_Name)
	{
		this.Category_Name = Category_Name;
	}


}
