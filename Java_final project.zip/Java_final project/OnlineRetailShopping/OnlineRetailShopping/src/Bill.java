

public class Bill {
	private String BillNumber;
	private String BillDate;
	private double PaidAmount;
	private String paymenttype;
	static int billCountint = 101;
	
	Bill()
	{
		BillNumber = "";
		BillDate = "";
		paymenttype = "";
		PaidAmount = 0;	
	
	}
	
	public String autoIncrement() {
		String billCount = ""+(billCountint);
		billCountint +=1;
		return billCount;
	}

Bill(String BillDate,String paymenttype,double PaidAmount)
	{
		this.BillNumber = autoIncrement();
		this.BillDate = BillDate;
		this.paymenttype = paymenttype;
		this.PaidAmount = PaidAmount;
		
	}
 

public String getBillNumber()
{
	return BillNumber;
}
public void setBillNumber(String BillNumber )
{
	this.BillNumber = BillNumber;
}

public String getBillDate()
{
	return BillDate;
}
public void setBillDate(String BillDate)
{
	this.BillDate = BillDate;
}

public String getpaymenttype()
{
	return paymenttype;
}
public void setpaymenttype(String paymenttype)
{
	this.paymenttype = paymenttype;
}

public Double getPaidAmount()
{
	return PaidAmount;
}
public void setPaidAmount(Double PaidAmount)
{
	this.PaidAmount = PaidAmount;
}
@Override
public String toString() {
	return "Bill [BillNumber=" + BillNumber + ", BillDate=" + BillDate + ",  paymenttype=" + paymenttype + ", Payment Amount=" + PaidAmount
			 + "]";
}	


}









