import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Productfile {

static Scanner keyboard = new Scanner(System.in);

static ArrayList<Product> Listofproducts = new ArrayList<Product>();
static ArrayList<Order> listofOrders = new ArrayList<Order>();
static ArrayList<Bill> ListofBills = new ArrayList<Bill>();
static ArrayList<Supplier> ListofSuppliers = new ArrayList<Supplier>();
	
public static void main(String[] args) throws FileNotFoundException
{	
	
   
    ArrayList<Category> ListofCategory = new ArrayList<Category>();
    
    
    LoadSupplier(ListofSuppliers);
   LoadCategory(ListofCategory);
    LoadProduct(Listofproducts);
    showmenu();
	
}

private static void showmenu() throws FileNotFoundException 
{
	
	do
	{
		System.out.println("Online Retail Management System\n");
		
		System.out.println("1. Press 1 for Shopping");
		System.out.println("2. Press 2 for Save");
		System.out.println("3. Press 3 for Exit");
		
		int input = keyboard.nextInt();
		
		switch (input)
		{
		case 1:
			shoppingOption();
			break;
		case 2:
			saveTranscation();
			break;
		case 3:
			System.out.println("Thank you for shopping");
			System.exit(0);
			break;
		default:
			System.out.println("Press Only 1,2 or 3");
			break;
		
		}
	}while(true);
	
}

private static void saveTranscation() throws FileNotFoundException {
	// TODO Auto-generated method stub
	PrintWriter writer = new PrintWriter("output.txt");
	for(Bill bill : ListofBills){
		writer.println(bill.toString());
	}
	int total = 0;
	for(Order order: listofOrders) {
		total += order.getPrice()*order.getQuantity();
		System.out.println("Bill=" + total);
		writer.println(order.toString());
		writer.println("Bill= "+ total);
	}
	
	writer.close();
	System.out.println("Orders Saved in output File");
	
}

static void shoppingOption() throws FileNotFoundException
{
	System.out.println("-----------------------------------------------------------------------");
	System.out.println("\t\t\tList of Products");
	System.out.println(" ID \tProduct Name \t Product Quntity\tProduct Price\tSupplier_Id");
	System.out.println("-----------------------------------------------------------------------");
	for(int i = 0; i<Listofproducts.size(); i++)
	{
		System.out.println(Listofproducts.get(i).getproductid() + "\t" + Listofproducts.get(i).getDescription() +"\t\t\t" + Listofproducts.get(i).getQuntity() +"\t\t" + Listofproducts.get(i).getproductprice()+"\t\t"+ Listofproducts.get(i).getIDNumber());
	}
	System.out.println("Enter the productId");
	keyboard.nextLine();
	String productid = keyboard.nextLine();
	
	System.out.println("enter the quntity you want to buy");
	int quntity = keyboard.nextInt();
	boolean found = false;
	for(Product product : Listofproducts)
	{
		if (product.getproductid().equalsIgnoreCase(productid))
		{
			found = true;
		if (product.getQuntity() > 0)
		{
			addOrder(product,quntity);
		}
		}
		
		
	}
}

private static void addOrder(Product product, int quntity) throws FileNotFoundException {
	System.out.println("ProductId:" + product.getproductid());
	System.out.println("ProductName:" + product.getDescription());
	System.out.println("ProductPrice:" + (product.getproductprice()) * quntity );
	System.out.println("SupplierId:"+ product.getIDNumber());
	System.out.println("Press 1 for continue");
	System.out.println("Press 2 for cancel");
	
	int input = keyboard.nextInt();
	
	switch (input)
	{
	case 1:
		Continue(product,quntity);
		break;
	case 2:
		showmenu();
		break;
	default:
		System.out.println("Press Only 1 or 2");
		break;
	}
}


private static void Continue(Product product, int i) {
	
	ListofBills.add(new Bill(new Date().toString(),"Cash",(product.getproductprice())*i));
	listofOrders.add(new Order(new Date().toString(),"Cash",i,ListofBills.get(0).getBillNumber(),"1",product.getproductid(),product.getproductprice(),product.getIDNumber()));
	for(Bill bill : ListofBills){
		System.out.println(bill.toString());
	}
	for(Order order : listofOrders) {
		System.out.println(order.toString());
	}
	
}

/*private static void LoadRegistration(ArrayList<Registration> listofUsers) throws FileNotFoundException 
{
	File file = new File("Registration.txt");
	
	Scanner userFile = new Scanner(file);
	String  UserDetails = "";
	
	while (userFile.hasNextLine())
	{
		UserDetails = userFile.nextLine();
		
		String[ ] userdetail = UserDetails.split(",");
		
		
		String IDNumber = userdetail[0];
		String Name = userdetail[1];
		String gender = userdetail[2];
		String ContactNo = userdetail[3]; 
		String Address = userdetail[4];
		String City = userdetail[5];
		String ZIP = userdetail[6];
		String State = userdetail[7];
		String Country = userdetail[8];
		String EmailId = userdetail[9];
		
		listofUsers.add(new Registration(IDNumber, Name, gender, ContactNo, Address, City, ZIP, State, Country, EmailId));
	}
	
	userFile.close();

	for (Registration registration : listofUsers) {
		System.out.println(registration.toString());
	}
	
}*/


private static void LoadProduct(ArrayList<Product> Listofproducts) throws FileNotFoundException 
{
File file = new File("Productfile.txt");
	
	Scanner productFile = new Scanner(file);
	String  ProductDetails = "";
	
	while (productFile.hasNextLine())
	{
		ProductDetails = productFile.nextLine();
		
		String[ ] productdetails = ProductDetails.split(",");
		
		String product_id = productdetails[0];
		String product_price = productdetails[1];
		String Description = productdetails[2];
		String IDNumber = productdetails[3];
		String Category_id = productdetails[4];
		String Quntity = productdetails[5]; 
		
		int quantity = Integer.parseInt(Quntity);
		int productPrice = Integer.parseInt(product_price);
		
		Listofproducts.add(new Product(product_id, productPrice, Description,IDNumber,Category_id, quantity));
	}
	productFile.close();
	
	for (Product product : Listofproducts) 
	{
		System.out.println(product.toString());
	}
	
		
	
}



private static void LoadCategory(ArrayList<Category> ListofCategory) throws FileNotFoundException 
{
File file = new File("Category.txt");
	
	Scanner CategoryFile = new Scanner(file);
	String  CategoryDetails = "";
	
	while (CategoryFile.hasNextLine())
	{
		CategoryDetails = CategoryFile.nextLine();
		
		String[ ] categorydetails = CategoryDetails.split(",");
		
		String Category_id = categorydetails [0];
		String Category_Name = categorydetails [1];
		
		ListofCategory.add(new Category(Category_id, Category_Name));
	}
	CategoryFile.close();
	
	for (Category category : ListofCategory) 
	{
		System.out.println(category.toString());
	}
	
}



private static void LoadSupplier(ArrayList<Supplier> listofSuppliers) throws FileNotFoundException 
{
	
File file = new File("Supplier.txt");
	
	Scanner SupplierFile = new Scanner(file);
	String  SupplierDetails = "";
	
	while (SupplierFile.hasNextLine())
	{
		SupplierDetails = SupplierFile.nextLine();
		
		String[ ] supplierdetails = SupplierDetails.split(",");
		
		String IDNumber = supplierdetails [0];
		String Name = supplierdetails [1];
		String ContactNo = supplierdetails [2]; 
		String Address = supplierdetails [3];
		String City = supplierdetails [4];
		String ZIP = supplierdetails [5];
		String Country = supplierdetails [6];
		
		listofSuppliers.add(new Supplier(IDNumber, Name, ContactNo, Address, City, ZIP, Country));
	}
	SupplierFile.close();
	
	for (Supplier supplier : listofSuppliers) 
	{
		System.out.println(supplier.toString());
	}
	
}
}



