
public class Order {
private String Order_id;
private String Order_Date;
private int Quantity;
private int Price; 
private String Payment_Type;
private String BillNumber;
private String custIDNumber;
private String product_id;
private String supIDNumber;

static int orderCountint=1001;

  public Order(String Order_Date,String Payment_Type,int Quantity, String BillNumber, String custIDNumber, String  product_id,int Price,String supIDNumber){
       this.Order_id = autoIncrement();
	   this.Order_Date = Order_Date;
	   this.Payment_Type = Payment_Type;
	   this.Quantity = Quantity;
	   this.BillNumber = BillNumber;
	   this.custIDNumber = custIDNumber;
	   this.product_id = product_id;
	   this.Price = Price;
	   this.supIDNumber = supIDNumber;
   }
  
  public String autoIncrement() {
		String orderCount = ""+(orderCountint);
		orderCountint +=1;
		return orderCount;
	}
public String getOrder_id() {
	return Order_id;
}
public void setOrder_id(String order_id) {
	Order_id = order_id;
}
public String getOrder_Date() {
	return Order_Date;
}
public void setOrder_Date(String order_Date) {
	Order_Date = order_Date;
}

public int getQuantity() {
	return Quantity;
}
public void setQuantity(int quantity) {
	Quantity = quantity;
}
public int getPrice() {
	return Price;
}
public void setPrice(int Price) {
	Price = Price;
}
public String getPayment_Type() {
	return Payment_Type;
}
@Override
public String toString() {
	return "Order [Order_id=" + Order_id + ", Order_Date=" + Order_Date + ", Quantity=" + Quantity + ", Payment_Type="
			+ Payment_Type + ", BillNumber=" + BillNumber + ", custIDNumber=" + custIDNumber + ", product_id="
			+ product_id + ", Product_Price=" + Price +", SupplierID=" + supIDNumber +"]";
}

public void setPayment_Type(String payment_Type) {
	Payment_Type = payment_Type;
}

public String getBillNumber() {
	return BillNumber;
}
public void setBillNumber(String billNumber) {
	BillNumber = billNumber;
}
public String getCustIDNumber() {
	return custIDNumber;
}
public void setCustIDNumber(String custIDNumber) {
	this.custIDNumber = custIDNumber;
}
public String getsupIDNumber() {
	return supIDNumber;
}
public void setsupIDNumber(String supIDNumber) {
	this.supIDNumber = supIDNumber;
}
public String getProduct_id() {
	return product_id;
}
public void setProduct_id(String product_id) {
	this.product_id = product_id;
}


}
