

public class Product {
private String product_id;
private String Description;
private String IDNumber;
private String Category_id;
private int Quntity,product_price;


Product(String product_id,int product_price,String Description, String IDNumber, String Category_id , int Quntity){
	this.product_id = product_id;
	this.product_price = product_price;
	this.Description = Description;
	this.IDNumber = IDNumber;
	this.Category_id = Category_id;
	this.Quntity = Quntity;
	
}
   public String getproductid()
	{
		return product_id;
	}
	public void setproductid(String product_id)
	{
		this.product_id = product_id;
	}
	public int getproductprice()
	{
		return product_price;
	}
	public void setproductprice(int product_price)
	{
		this.product_price = product_price;
	}
	public String getDescription()
	{
		return Description;
	}
	public void setDescription(String Description)
	{
		this.Description = Description;
	}
	
	
	public String getIDNumber() {
		return IDNumber;
	}
	public void setIDNumber(String iDNumber) {
		IDNumber = iDNumber;
	}
	public String getCategory_id() {
		return Category_id;
	}
	public void setCategory_id(String category_id) {
		Category_id = category_id;
	}
	
	
	public int getQuntity() {
		return Quntity;
	}
	public void setQuntity(int quntity) {
		Quntity = quntity;
	}
	
	
	public String toString() {
		return "Product [product_id=" + product_id + ", product_price=" + product_price + ", Product Name=" + Description
				+ ", SupplierId=" + IDNumber + ", Category_id=" + Category_id + ", Quntity=" + Quntity + "]";
	}
	
	


}
