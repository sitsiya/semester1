import java.util.ArrayList;

public class Supplier {
	private String IDNumber,ContactNo;
	private String Name,City,Address,ZIP,Country;

	
	
	
	Supplier(String IDNumber ,String Name,String ContactNo,String Address,String City,String ZIP,String Country)
	{	
		this.IDNumber = IDNumber;
		this.Name = Name;
		this.ContactNo = ContactNo;
		this.Address = Address;
		this.City = City;
		this.ZIP = ZIP;
		this.Country = Country;

	}
	
	public String getIDNumber()
	{
		return IDNumber;
	}
	public void setIDNumber(String IDNumber)
	{
		this.IDNumber = IDNumber;
	}
	
	public String getName()
	{
		return Name;
	}
	public void setName(String Name)
	{
		this.Name = Name;
	}
	public String getContactNo()
	{
		return ContactNo;
	}
	public void setContactNo(String ContactNo)
	{
		this.ContactNo = ContactNo;
	}
	public String getAddress()
	{
		return Address;
	}
	public void setAddress(String Address)
	{
		this.Address = Address;
	}
		public String getCity()
	{
		return City;
	}
	public void setCity(String City)
	{
		this.City = City;
	}
	public String getZIP()
	{
		return ZIP;
	}
	public void setZIP(String ZIP)
	{
		this.ZIP = ZIP;
	}
	public String getCountry()
	{
		return Country;
	}
	public void setCountry(String Country)
	{
		this.Country = Country;
	}

	@Override
	public String toString() {
		return "Supplier [Supplier_id=" + IDNumber + ", Contact No=" + ContactNo + ", Name=" + Name + ", City=" + City
				+ ", Address=" + Address + ", ZIP=" + ZIP + ", Country=" + Country + "]";
	}	
	
	
}
