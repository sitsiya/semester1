//
//  Registration.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation

class Registration
{
    
    public private(set) var id : Int = 0
    public private(set) var name : String
    public private(set) var gender : String
    public private(set) var contactNo : Int
    public private(set) var address : String
    public private(set) var city : String
    public private(set) var postalCode : String
    public private(set) var state : String
    public private(set) var country : String
    public private(set) var passWord : String
    static var count = 1
    
    
    init(){
        
        id = 0
        name = ""
        gender = ""
        contactNo = 0
        address = ""
        city = ""
        postalCode = ""
        state = ""
        country = ""
        passWord = ""
        //  id = id + 1
        
        
    }
    
    init(_ name : String,_ gender : String,_ contactNo : Int,_ address : String,_ city : String,_ postalCode : String,_ state : String,_ country : String,_ passWord : String)
    {
        
        self.name = name
        self.gender = gender
        self.contactNo = contactNo
        self.address = address
        self.city = city
        self.postalCode = postalCode
        self.state = state
        self.country = country
        self.passWord = passWord
        self.id = AutoIncrement()
        
    }
    func getId() -> Int
    {
        return id
    }
    func setId(_ Id : Int)
    {
        self.id = Id
    }
    
    func getName() -> String{
        return name
    }
    
    func setName(_ name : String){
        self.name = name
    }

    
    func getCustomerDetails() {
        print("ID \(self.id)")
        print("name \(self.name)")
        print("gender \(self.gender)")
        print("contactNo \(self.contactNo)")
        print("address \(self.address)")
        print("city \(self.city)")
        print("postalCode \(self.postalCode)")
        print("state \(self.state)")
        print("country \(self.country)")
        print("passWord \(self.passWord)")
        }
    
    func AutoIncrement() -> Int{
        let customerID = (Registration.count)
        Registration.count += 1
        return customerID
    }
    
}
