//
//  Category.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation
class  Category {
    public private(set) var  categoryid : Int = 0
    public private(set) var categoryname : String
    static var count = 100001

    
    init()
    {
        categoryid = 0
        categoryname = ""
        
    }
    init(_ categoryname : String ) {
        self.categoryname = categoryname
        self.categoryid = AutoIncrement()
    }
    
    func getCategoryId() -> Int
    {
        return categoryid
    }
    func setcategoryId(categoryId : Int)
    {
        self.categoryid = categoryId
    }

    
    func getCategoryDetails() {
        print("ID \(self.categoryid)")
        print("categoryName \(self.categoryname)")
        
    }
    func AutoIncrement() -> Int{
        let categoryID = (Category.count)
        Category.count += 1
        return categoryID
    }

}
