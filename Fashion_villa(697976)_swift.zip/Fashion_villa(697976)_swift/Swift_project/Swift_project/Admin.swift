//
//  Admin.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation



import Foundation
class Admin{
    
    var customers:[Registration]
    var products:[Product]
    var suppliers:[Supplier]
    var categories:[Category]
    var orders: [Order]
    var banks: [Bank]
    var bills: [Bill]
    var flag=0
    
    init(){
        customers = []
        products = []
        suppliers = []
        categories = []
        orders = []
        banks = []
        bills = []
    }
    
    
    //Customer
    
    //Add customer
    func addCustomer(_ name : String,_ gender : String,_ contactNo : Int,_ address : String,_ city : String,_ postalCode : String,_ state : String,_ country : String,_ passWord : String){
        customers.append(Registration(name,gender,contactNo,address,city,postalCode,state,country,passWord))
    }
    
    //Display customer
    func getCustomer(_ id:Int){
        flag = 0
        for i in customers{
            if i.id == id{
                i.getCustomerDetails()
                flag = 1
             }
        }
        if flag == 0{
            print("No Customer Found")
        }

    }
    
    //Delete Customer
    
    func DeleteCustomer(_ id : Int){
        
        flag = 0
        
        for i in 1 ... customers.count{
            if id == customers[i].getId(){
                customers.remove(at: i)
            }
        }
    }
    
    //Product
    
    //Add Product
    func addProduct(_ proName : String,_ proDescription : String,_ discount : Int,_ price : Int,_ quantity : Int,_ categoryid : Category,_ supplierid : Supplier){
        products.append(Product(proName,proDescription,discount,price,quantity,categoryid,supplierid))
    }
    
    //Display Product details
    
    func getProduct(_ proId:Int){
        flag = 0
        for i in products{
            if i.proId==proId{
                i.getProductDetails()
                flag = 1
            }
        }
        if flag == 0{
            print("No Product Found")
        }
    }
    
    //Category
    
    //Add categrory
    func addCategory(_ categoryid : Int,_ categoryname : String )
    {
        categories.append(Category())
    }
    
    //Display Category
    func getCategory(_ categoryid:Int)
    {
        flag = 0
        for i in categories{
            if i.categoryid==categoryid{
                i.getCategoryDetails()
                flag = 1
            }
        }
        if flag == 0{
            print("No Category Found")
        }
        
    }
    
    //Supplier
    
    //Add Supplier
    
    func addSupplier(_ name : String,_ contactNo : Int,_ address : String,_ city : String,_ postalCode : String,_ country : String)
    {
        
        suppliers.append(Supplier(name,contactNo,address,city,postalCode,country))
        
    }
    
    //Display Supplier
    func getSupplier(_ supId : Int)
    {
        flag = 0
        for i in suppliers{
            if i.supid == supId{
                i.getSupplierDetails()
                flag = 1
            }
        }
        if flag == 0{
            print("No Supplier Found")
        }
        
    }
    
    //Order
    
    //Add Order
    
    func addOrder(_ date : Date,_ orderStatus : String,_ paymentType : String,_ paymentStatus : String,_ orderQuantity : Int,_ productid : Product,_ customerid : Registration,_ supplierid : Supplier,_ bankid : Bank)  {
        
        orders.append(Order(date,orderStatus,paymentType,paymentStatus,orderQuantity,productid,customerid,supplierid,bankid))
        
    }
    
    //Display Order
    func getOrder(_ orderid:Int)
    {
        flag = 0
        for i in orders {
            if i.orderId == orderid {
                i.getOrderDetails()
                flag = 1
            }
        }
        if flag == 0{
            print("No Order Found")
        }
        
    }
    
    //Bank
    
    //Add bank
    func addBank(_ bankName : String,_ accountType : String,_ accountNo : Int , _ id : Registration){
        banks.append(Bank(bankName,accountType,accountNo,id))
    }
    
    
    //Display bank
    func getBank(_ bankid : Int)
    {
        flag = 0
        for i in banks {
            if i.bankId == bankid {
                i.getBankDetails()
                flag = 1
            }
        }
        if flag == 0 {
            print("No Bank Found")
        }
        
    }
    
    
    //Bill
    
    //Add Bill
    func addBill(_ BillNumber : Int,_ BillDate : Date, _ paymenttype : String,_ BankName : String, _ Amount : Double,_ id :Registration){
        bills.append(Bill(BillNumber,BillDate,paymenttype,BankName,Amount,id))
    }
    
    
    //Display Bill
    func getBill(_ transId:Int)
    {
        flag = 0
        for i in bills {
            if i.BillNumber == transId {
                i.getBillDetails()
                flag = 1
            }
        }
        if flag == 0 {
            print("No Bill Found")
        }
        
    }
    // w1
    
    func getOrderByMonth(_ month : Int, _ orders : [Order]){
        var count = 0;
        
        let calendar = Calendar.current
        
        for item in orders{
            let monthFromOrder = calendar.component(.month, from: item.date!)
            if (month == monthFromOrder) {
                count += 1
            }
        }
        
        print("Number of Product Sold in Month\(month) is \(count)")
    }
    
    // Product Sold By Gender
    
    func getProductsoldbygender (_ orders : [Order])
    {
        var Male = 0;
        var Female = 0;
        
        for item1 in orders{
            if item1.customerid.gender == "Male" {
                    Male += 1
            }else{
                Female += 1
            }
        }
        print("Male Count Is \(Male)")
        print("Female Count Is \(Female)")

    }
    
    func getTop5Customers(_ orders : [Order]){
        
        var customerId : [Int] = [Int]()
        
        for item1 in orders{
            customerId.append(item1.customerid.id)
        }
        
        print(customerId)
        
        var numberOfCounts : [Int : Int] = [ : ]
        
        for items in customerId{
            numberOfCounts[items] = (numberOfCounts[items] ?? 0) + 1
        }
        
        print(numberOfCounts)
        
        for (key, value) in Array(numberOfCounts).sorted(by: {$0.1 > $1.1}){
            print("Customer with ID \(key) purchased \(value) times")
        }
    }
    
    
    // Top 5 Customers
    
   /* func getOrderBySold (_ orders : [Order])
{
    var count1 = 0
    var Male = 0;
    var Female = 0;
    
    let gender = Registration[].gender
    
    for items in orders
    {
        if(gender == Female)
        {
            count1 += 1
            print("Total Female: \(count1)")
        }
        else
        {
            (gender == Male)
        }
    
    }*/
    
    
    
    
}


