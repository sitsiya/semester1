//
//  Supplier.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation
class Supplier
{
    public private(set) var supid : Int = 0
    public private(set) var name : String
    public private(set) var contactNo : Int
    public private(set) var address : String
    public private(set) var city : String
    public private(set) var postalCode : String
    public private(set) var country : String
    static var count = 1001

    
    
    
    init(_ name : String,_ contactNo : Int,_ address : String,_ city : String,_ postalCode : String,_ country : String)
    {
        self.name = name
        self.contactNo = contactNo
        self.address = address
        self.city = city
        self.postalCode = postalCode
        self.country = country
        self.supid = AutoIncrement()
        
    }
    
    func getSupId() -> Int
    {
        return supid
    }
    func setSupId(SupId : Int)
    {
        self.supid = SupId
    }

    

    
    
    func getSupplierDetails(){
        
        print("supId \(String(self.supid))")
        print("SuplierName \(self.name)")
        print("contactNo\(self.contactNo)")
        print("address \(self.address)")
        print("city\(self.city)")
        print("postalcode\(self.postalCode)")
        print("country\(self.country)")
        
        
    }
    func AutoIncrement() -> Int{
        let supplerID = (Supplier.count)
        Supplier.count += 1
        return supplerID
    }

    
    
}
