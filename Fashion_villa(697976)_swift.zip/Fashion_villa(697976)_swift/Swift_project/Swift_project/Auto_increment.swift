//
//  AutoIncrementFile.swift
//  tempProduct
//
//  Created by MacStudent on 2017-06-12.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation

class  AutoIncrementFile {
    
    static var customerCount = 101
    static var productCount = 101
    static var supplierCount = 1001
    static var orderCount = 1001
    static var categoryCount = 101
    static var bankCount = 101
    
    
    
    
    func autoIncrementCustomer() -> Int{
        let customerCount =  Int(AutoIncrementFile.customerCount)
        AutoIncrementFile.customerCount += 1
        return customerCount
    }
    
    func autoIncrementProduct() -> Int{
        let productCount = Int(AutoIncrementFile.productCount)
        AutoIncrementFile.productCount += 1
        return productCount
    }
    
    func autoIncrementCategory() -> Int{
        let categoryCount = Int(AutoIncrementFile.categoryCount)
        AutoIncrementFile.categoryCount += 1
        return categoryCount
    }
    
    func autoIncrementSupplier() -> Int{
        let supplierCount = Int(AutoIncrementFile.supplierCount)
        AutoIncrementFile.supplierCount += 1
        return supplierCount
    }
    
    func autoIncrementOrder() -> Int{
        let orderCount = Int(AutoIncrementFile.orderCount)
        AutoIncrementFile.orderCount += 1
        return orderCount
    }
    
    func autoIncrementBank() -> Int{
        let bankCount = Int(AutoIncrementFile.bankCount)
        AutoIncrementFile.bankCount += 1
        return bankCount
    }
    
}
