//
//  Bank.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation
class Bank
{
    public private(set) var bankId : Int = 0
    public private(set) var bankName : String
    public private(set) var accountType : String
    public private(set) var accountNo : Int
    public private(set) var id : Registration
    static var count = 01

    
    
    
    init(_ bankName : String,_ accountType : String,_ accountNo : Int , _ id : Registration)
    {
        self.bankName = bankName
        self.accountType = accountType
        self.accountNo = accountNo
        self.id = id
        self.bankId = AutoIncrement()
    }
    
    func getBankId() -> Int
    {
        return bankId
    }
    func setBankId(BankId : Int)
    {
        self.bankId = BankId
    }

    func getBankDetails(){
        
        print("bankId: \(self.bankId)")
        print("BankName: \(self.bankName)")
        print("accountType:\(self.accountType)")
        print("accountNo:\(self.accountNo)")
        print("customer Id:\(id.getId())")
        
    }
    
    func AutoIncrement() -> Int{
        let bankID = (Bank.count)
        Bank.count += 1
        return bankID
    }

    
}
