//
//  Order.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation
class  Order {
    
    public private(set) var orderId : Int = 0
    public private(set) var date : Date?
    public private(set) var orderStatus : String
    public private(set) var paymentType : String
    public private(set) var paymentStatus : String
    public private(set) var orderQuantity : Int
    public private(set) var productid : Product
    public var customerid : Registration
    public var supplierid : Supplier
    public var bankid : Bank
    static var count = 1010

    
    
    init(_ date : Date,_ orderStatus : String,_ paymentType : String,_ paymentStatus : String,_ orderQuantity : Int,_ productid : Product,_ customerid : Registration,_ supplierid : Supplier,_ bankid : Bank)
    {
        self.date = date
        self.orderStatus = orderStatus
        self.paymentType = paymentType
        self.paymentStatus = paymentStatus
        self.orderQuantity = orderQuantity
        self.productid = productid
        self.customerid = customerid
        self.supplierid = supplierid
        self.bankid = bankid
        self.orderId = AutoIncrement()
    }
    
    func getOrderId() -> Int
    {
        return orderId
    }
    func setOrderId(OrderId : Int)
    {
        self.orderId = OrderId
    }

    
    func getOrderDetails() {
        print("orderID: \(self.orderId)")
        print("OrderDate: \(String(describing: self.date))")
        print("OrderStatus: \(self.orderStatus)")
        print("paymentType: \(self.paymentType)")
        print("paymentStatus: \(self.paymentStatus)")
        print("orderQuality: \(self.orderQuantity)")
        print("CustomerId:\(customerid.getId())")
        print("ProductId: \(productid.getProId())")
        print("SupplierId: \(supplierid.getSupId())")
        print("BankId: \(bankid.getBankId())")
        
        print("......................................")
        
        
       /* print("productid: \(productid.getProductDetails())")
        print("customerid: \(customerid.getCustomerDetails())")
        print("supplierid: \(supplierid.getSupplierDetails())")
        print("bankid: \(bankid.getBankDetails())")*/
    }
    func AutoIncrement() -> Int{
        let orderID = (Order.count)
        Order.count += 1
        return orderID
    }

}
