//
//  main.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation



let formatter = DateFormatter()
formatter.dateFormat = "yyyy-MM-dd"
//

//ADD CUSTOMER

var customer1 = Registration("Damini", "Female", 6479297158, "Don Mills", "Toronto", "M2J3C3", "Ontario", "Aust", "dami12")
var customer2 = Registration("Chaitali", "Female", 6479027899, "Markham", "Toronto", "M2B33", "Ontario", "Canada", "abc")
var customer3 = Registration("Manpreet", "Female", 8488803416, "Brambton", "Toronto", "364001", "Ontario", "Canada", "mann123")
var customer4 = Registration("Deep", "Male", 9904174733, "Doon", "Toronto", "m34567", "Qubec", "Canada", "deppp")
var customer5 = Registration("Ankur", "Male", 6479297070, "Scarborogh","Toronto", "SCT900", "Toronto", "Canada","0001a")
var customer6 = Registration("Dakshesh", "Male", 6479296658, "york Mills", "Toronto", "M2J2C3", "Ontario", "Aust", "dakshesh5")
var customer7 = Registration("Chaitanya", "Male", 6479027834, "Markham", "Toronto", "M2B3G3", "Ontario", "Canada", "fjjkcvsjk")
var customer8 = Registration("Megha", "Female", 8488834516, "Brambton", "Toronto", "M1XS01", "Ontario", "Canada", "mafjnknc")
var customer9 = Registration("Deepika", "Female", 9347874733, "Dons", "Ottava", "m34567", "Menitoba", "Canada", "dephadih")
var customer10 = Registration("Annish", "Male", 64792934570, "Scarborogh","Toronto", "SCT430", "Toronto", "Canada","34829uosj")

var customer : [Registration] = [Registration]()
customer.append(customer1)
customer.append(customer2)
customer.append(customer3)
customer.append(customer4)
customer.append(customer5)
customer.append(customer6)
customer.append(customer7)
customer.append(customer8)
customer.append(customer9)
customer.append(customer10)

// ADD SUPPLIER

var supplier1 = Supplier("Tushar",6472447260,"225 Van Horne","Don Mills","M2J2T9","Canada")
var supplier2 = Supplier("Nandi", 4176906767, "Von Mills", "Toronto", "M2j3C2", "Canada")
var supplier3 = Supplier("Avani", 4176906760, "Don Mills", "Toronto", "VJB001", "Canada")
var supplier4 = Supplier("Karan", 647890987, "Don Vallys", "Toronto", "M2J3C3", "Canada")
var supplier5 = Supplier("Vishal", 4176906709, "Kanaddy", "Toronto", "KO987", "Canada")
var supplier6 = Supplier("Shreyas",6472687260,"Markham","Don Mills","M2J2T9","Canada")
var supplier7 = Supplier("Vanita", 4176954767, "Ellesmere", "Toronto", "M2j3C2", "Canada")
var supplier8 = Supplier("Nishit", 4176677760, "Victoria Park", "Toronto", "M1G2V5", "Canada")

var supplier : [Supplier] = [Supplier]()
supplier.append(supplier1)
supplier.append(supplier2)
supplier.append(supplier3)
supplier.append(supplier4)
supplier.append(supplier5)
supplier.append(supplier6)
supplier.append(supplier7)
supplier.append(supplier8)




//ADD CATEGORY
var category1 = Category("Scarf")
var category2 = Category("Skirts")
var category3 = Category("Jacket")
var category4 = Category("Jeans")
var category5 = Category("Leggings")
var category6 = Category("Top")
var category7 = Category("Tunic")
var category8 = Category("Saree")
var category9 = Category("Shirt")
var category10 = Category("Dress")

var category : [Category] = [Category]()
category.append(category1)
category.append(category2)
category.append(category3)
category.append(category4)
category.append(category5)
category.append(category6)
category.append(category7)
category.append(category8)
category.append(category9)
category.append(category10)

// ADD PRODUCT
var product1 = Product("Scarf","size-32 sky blue",10,160,30,category3,supplier1)
var product2 = Product("Jeans", "size-32 sky blue",10,1600,30,category1,supplier2)
var product3 = Product("Skirts", "Chocolate color",15,100,10,category2,supplier3)
var product4 = Product("Jacket", "size-s  blue",20,160,35,category3,supplier3)
var product5 = Product("Leggings", "size-l black",05,20,50,category2,supplier5)
var product6 = Product("Top","size-32 sky blue",10,500,30,category2,supplier1)
var product7 = Product("Tunics", "size-32 sky blue",10,700,30,category4,supplier2)
var product8 = Product("Skirts", "Chocolate color",15,1000,10,category3,supplier3)
var product9 = Product("Saree", "size-s  blue",20,560,35,category1,supplier3)
var product10 = Product("Dress", "size-l black",05,2500,50,category5,supplier5)

var product : [Product] = [Product]()
product.append(product1)
product.append(product2)
product.append(product3)
product.append(product4)
product.append(product5)
product.append(product6)
product.append(product7)
product.append(product8)
product.append(product9)
product.append(product10)


//ADD Bank

var bank1 = Bank( "Scotia Bank", "Saving", 98765432,customer1)
var bank2 = Bank( "RBC Bank", "Credit", 23456780,customer2)
var bank3 = Bank( "ICICI Bank", "Saving", 09097057,customer3)
var bank4 = Bank( "HDFC Bank", "Saving", 98765420,customer4)
var bank5 = Bank( "Western Union", "Credit", 69802134,customer5)


var bank : [Bank] = [Bank]()
bank.append(bank1)
bank.append(bank2)
bank.append(bank3)
bank.append(bank4)
bank.append(bank5)


//ADD Bills

var bill1 = Bill(101,formatter.date(from: "2015-08-11")!,"Credit Card","Scotia Bank", 1000,customer1)
var bill2 = Bill(102,formatter.date(from: "2017-01-03")!,"Debit Card","HDFC Bank", 1000,customer2)
var bill3 = Bill(103,formatter.date(from: "2016-09-21")!,"Debit Card","Scotia Bank", 160,customer4)
var bill4 = Bill(104,formatter.date(from: "2016-01-10")!,"Credit Card","Scotia Bank", 100,customer3)
var bill5 = Bill(105,formatter.date(from: "2017-05-10")!,"Debit Card","Western Union", 720,customer5)
var bill6 = Bill(106,formatter.date(from: "2015-05-11")!,"Credit Card","Scotia Bank", 1000,customer6)
var bill7 = Bill(107,formatter.date(from: "2017-01-09")!,"Debit Card","HDFC Bank", 1000,customer7)
var bill8 = Bill(108,formatter.date(from: "2016-09-22")!,"Debit Card","Scotia Bank", 1600,customer8)
var bill9 = Bill(109,formatter.date(from: "2016-11-07")!,"Credit Card","Scotia Bank", 1200,customer9)
var bill10 = Bill(110,formatter.date(from: "2017-05-19")!,"Debit Card","Western Union", 120,customer10)


var bill : [Bill] = [Bill]()
bill.append(bill1)
bill.append(bill2)
bill.append(bill3)
bill.append(bill4)
bill.append(bill5)
bill.append(bill6)
bill.append(bill7)
bill.append(bill8)
bill.append(bill9)
bill.append(bill10)


//ADD ORDERS

var order1 = Order(formatter.date(from: "2015-08-09")!,"Pending", "Credit Card", "Done", 01,product1,customer1,supplier1,bank1)
var order2 = Order(formatter.date(from: "2017-05-01")!,"Done", "Debit Card", "Pending", 05,product2,customer2,supplier2,bank2)
var order3 = Order(formatter.date(from: "2016-09-20")!,"Done", "Credit Card", "Done",02,product3,customer3,supplier3,bank3)
var order4 = Order(formatter.date(from: "2017-06-07")!,"Done", "Debit Card", "Done", 10,product4,customer4,supplier3,bank4)
var order5 = Order(formatter.date(from: "2017-05-10")!,"Pending", "Credit Card", "Pending", 03,product5,customer5,supplier5,bank5)

var order : [Order] = [Order]()
order.append(order1)
order.append(order2)
order.append(order3)
order.append(order4)
order.append(order5)

order1.getOrderDetails()
order2.getOrderDetails()
/*bill1.getBillDetails()
bank1.getBankDetails()
product1.getProductDetails()
category1.getCategoryDetails()
supplier1.getSupplierDetails()
customer1.getCustomerDetails()*/



//print("WardBoy \(shift3.nurse[105].getName()) 's name and date of birth updated: \(shift3.UpdateNurse(IDNumber: 105, Name: "nandi", DOB: "20/05/1990", Address: "19 donmills on", ContactNo: 6759899, DOJ: "25/07/2016", IsActive: 1, PIN: "B57FON6")))");

//print("Receptionist \(shift3.admin[9].getName()) deleted :\(shift3.DeleteAdmin(IDNumber: 9))");


var admin = Admin()
admin.getOrderByMonth(05, order)
admin.getProductsoldbygender(order)
admin.getTop5Customers(order)
print("----------------")
print(customers.count)
admin.DeleteCustomer(customer6.id)


