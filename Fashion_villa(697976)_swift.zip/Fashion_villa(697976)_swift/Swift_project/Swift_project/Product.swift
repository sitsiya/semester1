//
//  Product.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation
class Product
{
    
    public private(set) var proId : Int = 0
    public private(set) var proName : String
    public private(set) var proDescription : String
    public private(set) var discount : Int
    public private(set) var price : Int
    public private(set) var quantity : Int
    public private(set) var categoryid  : Category
    public private(set) var supplierid  : Supplier
    static var count = 0001

    
    init(_ proName : String,_ proDescription : String,_ discount : Int,_ price : Int,_ quantity : Int,_ categoryid : Category,_ supplierid : Supplier)
    {
        self.proName = proName
        self.proDescription = proDescription
        self.discount = discount
        self.price = price
        self.quantity = quantity
        self.categoryid = categoryid
        self.supplierid = supplierid
        self.proId = AutoIncrement()
        
    }
    
    func getProId() -> Int
    {
        return proId
    }
    func setProId(_ ProId : Int)
    {
        self.proId = ProId
    }

    
    func getProductDetails(){
        
        print("proId \(self.proId)")
        print("proName \(self.proName)")
        print("proDescription\(self.proDescription)")
        print("discount\(self.discount)")
        print("price\(self.price)")
        print("quantity\(self.quantity)")
        print("CategoryId:\(categoryid.getCategoryId())")
        print("SupplierId:\(supplierid.getSupId())")
        print("..........................................")
        /*print("categoryid\(categoryid.getCategoryDetails())")
        print("supplierid\(supplierid.getSupplierDetails())")*/
        
        
    }
    func AutoIncrement() -> Int{
        let productID = (Product.count)
        Product.count += 1
        return productID
    }

}

