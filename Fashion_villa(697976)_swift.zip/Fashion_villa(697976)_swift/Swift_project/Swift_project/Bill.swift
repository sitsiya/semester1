//
//  Bill.swift
//  Swift_project
//
//  Created by Damini Dholakiya on 2017-06-09.
//  Copyright © 2017 Damini Dholakiya. All rights reserved.
//

import Foundation

class Bill
{
    public private(set) var BillNumber : Int
    public private(set) var BillDate : Date?
    public private(set) var paymenttype : String
    public private(set) var BankName : String
    public private(set) var Amount : Double
    public private(set) var id : Registration
    static var count = 101

    
    init() {
        BillNumber = 0
        BillDate = nil
        paymenttype = ""
        BankName = ""
        Amount = 0
        id = Registration()
    }
    
    init(_ BillNumber : Int,_ BillDate : Date, _ paymenttype : String,_ BankName : String, _ Amount : Double,_ id :Registration)
    {
        self.BillNumber = BillNumber
        self.BillDate = BillDate
        self.paymenttype = paymenttype
        self.BankName = BankName
        self.Amount = Amount
        self.id = id
    }
    
    func setBillNumber  (BillNumber : Int)
    {
        self.BillNumber = BillNumber
    }
    func getBillNumber  () -> Int
    {
        return BillNumber
    }

    
    func getBillDetails() {
        print("Billnumber: \(self.BillNumber)")
        print("BillDate: \(String(describing: self.BillDate))")
        print("paymenttype: \(self.paymenttype)")
        print("BankName: \(self.BankName)")
        print("Amount: \(self.Amount)")
        print("CusTomerId:\(id.getId())")
        print(".....................................")
       // print("Customer_id: \(id.getCustomerDetails())")
        
        
        
    }
    
    
}
